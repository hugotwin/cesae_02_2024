package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityMain5Binding

class MainActivity5 : AppCompatActivity() {

    private val binding by lazy {
        ActivityMain5Binding.inflate(layoutInflater)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)

        val i = intent

        val nome_produto = i.extras?.getString("nome_produto").toString()
        val preco_produto = i.extras?.getString("preco_produto").toString()
        val quantidade_produto = i.extras?.getString("quantidade").toString()
        var nome = i.extras?.getString("nome").toString()

        binding.textNome.text ="nome : ${nome_produto}"
        binding.textPreco.text ="Preco : ${preco_produto}"
        binding.textQuantidade.text ="Quantidade: ${quantidade_produto}"





        binding.btnRetroceder.setOnClickListener{

            val retroceder:String = "ok"
            val i =  Intent(this,MainActivity4::class.java)
            i.putExtra("nome_produto",nome_produto)
            i.putExtra("preco_produto",preco_produto)
            i.putExtra("quantidade_produto",quantidade_produto)
            i.putExtra("retroceder", retroceder )

            startActivity(i)


        }

        binding.btnMenu.setOnClickListener{

            Toast.makeText(applicationContext, "Produto inserido", Toast.LENGTH_SHORT).show()


            val i =  Intent(this,MainActivity3::class.java)
            i.putExtra("nome", nome)

            startActivity(i)


        }






    }
}