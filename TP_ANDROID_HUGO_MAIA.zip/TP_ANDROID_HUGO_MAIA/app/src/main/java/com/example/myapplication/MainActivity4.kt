package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityMain4Binding

class MainActivity4 : AppCompatActivity() {


    private val binding by lazy {
        ActivityMain4Binding.inflate(layoutInflater)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)


        var nome_produto:String ="";

        val i = intent
        nome_produto =  i.extras?.getString("nome_produto").toString()
        var preco_produto = i.extras?.getString("preco_produto").toString()
        var quantidade_produto = i.extras?.getString("quantidade_produto").toString()
        var retroceder = i.extras?.getString("retroceder").toString()
        var nome = i.extras?.getString("nome").toString()

        if(retroceder=="ok"){

            binding.textEditNome.hint= nome_produto
            binding.textEditPreco.hint=preco_produto
            binding.textEditQunatidade.hint=quantidade_produto

        }


        binding.buttonRegisto.setOnClickListener {


            val nomeProduto = binding.textEditNome.text.toString()
            val precoProduto = binding.textEditPreco.text.toString()
            val quantidade = binding.textEditQunatidade.text.toString()

            if (nomeProduto.isEmpty() || precoProduto.isEmpty() || quantidade.isEmpty()) {
                Toast.makeText(this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, MainActivity5::class.java)
                intent.putExtra("nome_produto", nomeProduto)
                intent.putExtra("preco_produto", precoProduto)
                intent.putExtra("quantidade", quantidade)
                intent.putExtra("nome", nome)
                startActivity(intent)
            }
        }





    }
}