package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)


        binding.buttonLogin.setOnClickListener {
            var username: String = binding.textEditUsername.text.toString()
            var password: String = binding.textEditPassword.text.toString()

            val nome  = binding.textEditUsername.text.toString()


            binding.textEditUsername.setText("") // ou setText ou clear (funcionam da mesma maneira)
            binding.textEditPassword.text.clear()


            if(username.equals("user") && password.equals("pass")){
                // Login valido
                Toast.makeText(applicationContext, "Login Válido", Toast.LENGTH_SHORT).show()


                // Mudar de atividade
               val i =  Intent(this,MainActivity3::class.java)
                i.putExtra("nome",nome )
                startActivity(i)

            }else{
                // Login invalido
                Toast.makeText(applicationContext, "Login Inválido", Toast.LENGTH_SHORT).show()
            }
        }






    }
}